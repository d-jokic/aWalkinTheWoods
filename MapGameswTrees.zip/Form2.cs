﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO.Ports;



namespace $safeprojectname$
{
    public partial class Form2 : Form

    {
        private static System.Timers.Timer aTimer;

        public Form2()
        {
            InitializeComponent();
            PictureBox pictureBox1 = new PictureBox();
            makeBackground(pictureBox1);
            //makePath(pictureBox1);
        }

        public void makeBackground(PictureBox box)
        {

            box.Size = new Size(1200, 550);
            this.Controls.Add(box);
            Bitmap flag = new Bitmap(1200, 550);
            Graphics flagGraphics = Graphics.FromImage(flag);
            this.BackColor = System.Drawing.Color.ForestGreen;
            Image newImage = Image.FromFile("C:/Users/Cindy/Documents/1B/MapGamesTrees/Trent-1.png");
            flagGraphics.CompositingMode = System.Drawing.Drawing2D.CompositingMode.SourceOver;

            int xplot = 50;
            int yplot = 50;

            for (int i = 0; i < 1200; i += 50)
            {
                yplot = intArray.valToShare[i];


                float width = 100;

                float scale = Math.Min(width / newImage.Width, yplot);

                var scaleWidth = (int)(newImage.Width * scale);

                flagGraphics.DrawImage(newImage, new Rectangle(xplot - 25, 500 - yplot, scaleWidth, yplot));

                xplot += 50;

            }
            
            int xPrev = 0;
            int yPrev = 0;
            int x = 0;
            int y = 250;


            SerialPort input = new SerialPort();
            input.BaudRate = 9600;
            input.PortName = "COM4";
            input.Open();

            int positionIntv = 0;
            int speed = 0;
            string[] temp;

            for (int i = 0; x < 1200; i += 10)
            {
                x += 10;
                string readIn = input.ReadLine();
                temp = readIn.Split(',');

                positionIntv = Convert.ToInt32(temp[0]);
                speed = Convert.ToInt32(temp[1]);

                if ((positionIntv != 0) && (yPrev < 550) && (yPrev > 0))
                {
                    y += (25 * positionIntv);
                }
                Console.WriteLine(positionIntv);
                flagGraphics.FillEllipse(Brushes.Blue, xPrev, yPrev, 5, 5);
                flagGraphics.FillEllipse(Brushes.Red, x, y, 5, 5);
                this.Update();
                box.Image = flag;

                xPrev = x;
                yPrev = y;
                //x += heartrate;
            }
            input.Close();
            
            
        }

        public void makePath(PictureBox box)
        {
            Bitmap path = new Bitmap(1200, 550);
            path.MakeTransparent();
            Graphics pathGraphics = Graphics.FromImage(path);

            int heartrate = 1;
            int xPrev = 0;
            int yPrev = 0;
            int x = 0;
            int y = 250;
           

            SerialPort input = new SerialPort();
            input.BaudRate = 9600;
            input.PortName = "COM4";
            input.Open();

            int positionIntv = 0;
            int speed = 0;
            string[] temp;

            for (int i = 0; x < 1200; i+=10)
            {
                x += 10;
                string readIn = input.ReadLine();
                temp = readIn.Split(',');

                positionIntv = Convert.ToInt32(temp[0]);
                speed = Convert.ToInt32(temp[1]);

                if ((positionIntv != 0) && (yPrev < 550) && (yPrev > 0)) {
                    y += (25 * positionIntv);
                }
                Console.WriteLine(positionIntv);
                pathGraphics.FillEllipse(Brushes.Blue, xPrev, yPrev, 5, 5);
                pathGraphics.FillEllipse(Brushes.Red, x, y, 5, 5);
                this.Update();

                xPrev = x;
                yPrev = y;
                //x += heartrate;
            }
            input.Close();
            box.Image = path;
        }
    /*private static void SetTimer(Graphics flagGraphics, int xPrev, int yPrev, int x, int y, int heartrate, timer)
    {
        aTimer = new System.Timers.Timer(2000);
        OnTimedEvent(flagGraphics, xPrev, yPrev, x, y, heartrate);
        aTimer.AutoReset = true;
        aTimer.Enabled = true;

    }
    //private static void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)//, int x, int y, Graphics flagGraphics, int heartrate, EventArgs e)
    private static void OnTimedEvent(Graphics flagGraphics, int xPrev, int yPrev, int x, int y, int heartrate, System.Timers.ElapsedEventArgs e)
    {
        //Form2DrawPoint(flagGraphics, xPrev, yPrev, x, y, heartrate);
        flagGraphics.FillEllipse(Brushes.Blue, xPrev, yPrev, 5, 5);
        flagGraphics.FillEllipse(Brushes.Red, x, y, 5, 5);
        xPrev = x;
        yPrev = y;
        x += heartrate;
    }
public void DrawPoint(Graphics flagGraphics, int xPrev, int yPrev, int x, int y, int heartrate)
    {
        flagGraphics.FillEllipse(Brushes.Blue, xPrev, yPrev, 5, 5);
        flagGraphics.FillEllipse(Brushes.Red, x, y, 5, 5);
        xPrev = x;
        yPrev = y;
        x += heartrate;
    }*/

    private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.character = new System.Windows.Forms.Panel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();

            this.ClientSize = new System.Drawing.Size(1200, 550);

            /*
            // 
            // character
            // 
            this.character.Location = new System.Drawing.Point(481, 143);
            this.character.Name = "character";
            this.character.Size = new System.Drawing.Size(10, 10);
            this.character.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // Form2
            // 
            //this.BackColor = System.Drawing.Color.ForestGreen;
            //this.Controls.Add(this.character);
            //this.Name = "Form2";
           // this.Text = "A Walk in the Woods";
            //this.LocationChanged += new System.EventHandler(this.timer1_Tick_1);
            //this.ResumeLayout(false);
            */
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            //pictureBox1.Update();
            //character.Update();
        }
    }
}
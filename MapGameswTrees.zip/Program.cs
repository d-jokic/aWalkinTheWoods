﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using System.IO.Ports;
using System.Collections;

namespace $safeprojectname$
{
    public static class intArray
    {
        public static Int32[] valToShare = new Int32[1200];

    }


    static class Program
    {

        [STAThread]
        static void Main()
        {
            SerialPort input = new SerialPort();
            input.BaudRate = 9600;
            input.PortName = "COM4";
            input.Open();
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);


            int y = 0;
            int interim = 0;
            for (int i = 0; i < 1199; i++)
            {
                string readIn = input.ReadLine();
                interim = Int32.Parse(readIn);
                y = Convert.ToInt32(interim);
                intArray.valToShare[i] = y;
            }

            input.Close();
            Application.Run(new Form2());
        }

    }

}
